//
//  UMSWechatDataTypeTableViewController.h
//  SocialSDK
//
//  Created by umeng on 16/4/14.
//  Copyright © 2016年 dongjianxiong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UMShare/UMShare.h>

@interface UMSocialWechatHandler : UMSocialHandler

+ (instancetype)defaultManager;

@end
